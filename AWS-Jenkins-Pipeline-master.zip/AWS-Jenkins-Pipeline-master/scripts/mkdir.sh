mkdir -p /web
curl -O https://bootstrap.pypa.io/get-pip.py
python get-pip.py --user
python -m pip install Flask
#sdssdsds

