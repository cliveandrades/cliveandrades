python /web/web.py > /dev/null 2>&1 &
